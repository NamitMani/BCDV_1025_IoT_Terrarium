import React, { useState, useEffect } from 'react';

const QueryHF = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    // Fetch API data and update the 'data' state
    fetch('http://4.204.190.172:3000/queryAllDevices')
      .then(response => response.json())
      .then(data => setData(data))
      .catch(error => console.error(error));
  }, []);

console.log(data);
  return (
    <ol>
      {data.map(item => (
        <li key={item.identity} align="left">
          {item.identity}
        </li>
      ))}
    </ol>
  );
}

export default QueryHF;
