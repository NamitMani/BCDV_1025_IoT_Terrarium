import {Link} from "react-router-dom";
import { Box, Container, Grid, Typography } from "@mui/material";

const Footer = () => {
  return (
    <Box
      sx={{
        width: "100%",
        height: "auto",
        backgroundColor: "primary.main",
        paddingTop: "1rem",
        paddingBottom: "1rem",
        position: "fixed", bottom: 0
      }}
    >
      <Container maxWidth="lg">
        <Grid container direction="column" alignItems="center">
          <Grid item xs={12}>
          </Grid>
          <Grid item xs={12}>
            <Typography color="#FFFFFF" >
                   <Link to="/"> Home</Link>  <Link to="/buypet"> Buy Pet</Link> <Link to="/buytank"> Buy Tank</Link> <Link to="/starttank"> Start Tank</Link>
            </Typography>
            </Grid>
        </Grid>
      </Container>
    </Box>

  )
}

export default Footer;