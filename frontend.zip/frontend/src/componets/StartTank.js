import React, { useState, useEffect } from 'react';

const StartTank = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    // Fetch API data and update the 'data' state
    fetch('https://jsonplaceholder.typicode.com/posts')
      .then(response => response.json())
      .then(data => setData(data))
      .catch(error => console.error(error));
  }, []);

console.log(data);
  return (
    <ol>
      {data.map(item => (
        <li key={item.id} align="left">
          {item.title}
        </li>
      ))}
    </ol>
  );
}

export default StartTank;