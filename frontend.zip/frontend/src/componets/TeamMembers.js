import React from 'react';
const teams =['Aniket', 'Badaruddin', 'Fawaz', 'Hermanth', 'Namit'];
const TeamMembers = () => {
   

  return (
    <div>
        Teams
            <ol>
      {teams.map(index => (
        <li key={index} align="left">
          {index}
        </li>
      ))}
    </ol>

    </div>

  );
}

export default TeamMembers;