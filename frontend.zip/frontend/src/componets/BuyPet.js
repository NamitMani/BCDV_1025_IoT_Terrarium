import React from 'react';
import { useForm } from 'react-hook-form';

const BuyPet = () => {
    const { register, handleSubmit } = useForm();

    const onSubmit = (data) => {
      const jsonData = {
        username: data.username,
        age: data.age
      };
      const jsonDataString = JSON.stringify(jsonData);
      const blob = new Blob([jsonDataString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'data.json');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    };
  
    return (
      <form onSubmit={handleSubmit(onSubmit)}>
        <div>
          <label htmlFor="username">Username:</label>
          <input {...register('username')} type="text" id="username" />
        </div>
        <div>
          <label htmlFor="age">Age:</label>
          <input {...register('age')} type="number" id="age" />
        </div>
        <button type="submit">Submit</button>
      </form>
    );
  }

export default BuyPet;