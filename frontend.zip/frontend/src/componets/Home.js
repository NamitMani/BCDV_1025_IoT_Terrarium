import React from 'react';
import { Grid, Button, Box,Typography } from '@mui/material';
const clickable_url =['buypet','buytank', 'starttank'];

const handleClickBuyPet = () => {
   window.open('/buypet');
 };
 const handleClickBuyTank = () => {
   window.open('/buytank');
 };
 const handleClickStartTank = () => {
   window.open('/starttank');
 };

const Home = () => {

  return <div >
    <Typography variant="h5" align="left" m={1}> Autorium Solution     </Typography>
       <Box align="left" m={1} p={2}> Autorium is a comprehensive solution for buying pets, tanks, and starting your own aquarium. 
       Setting up an aquarium requires careful consideration and proper equipment to ensure the well-being of the aquatic pets. 
       Before purchasing any pets, it is important to learn about aquarium setup and maintenance. The Spruce Pets provides a helpful 
       checklist for beginners, which includes essential supplies such as an aquarium, filtration system, decorations, heater, light, and more <br/><br/>
       It is crucial to choose an appropriate tank size and ensure proper support for the tank to avoid any mishaps. 
       Additionally, considering the cost and making a checklist of necessary equipment and supplies can help in budgeting and planning.
        For beginners, starter aquarium kits can be a convenient option, providing all the essential components for a successful aquarium setup. 
        By following proper guidelines and investing in the right equipment, Autorium aims to make the process of buying pets, tanks, and starting an aquarium more accessible and enjoyable.
      </Box>

<Grid container spacing={2}>
<hr  width="90%"/>
      <Grid item xs={3}>
        <Button variant="contained" color="primary" onClick={handleClickBuyPet} >
          BUY PET
        </Button>
      </Grid>
      <Grid item xs={9}>
        <div>
          Dummy Text
        </div>
      </Grid>
      <hr  width="90%"/>
      <Grid item xs={3}>
        <Button variant="contained" color="primary" onClick={handleClickBuyTank}>
          BUY TANK
        </Button>
      </Grid>
      <Grid item xs={9}>
        <div>
          Dummy Text
        </div>
      </Grid>
      <hr  width="90%"/>
      <Grid item xs={3}>
        <Button variant="contained" color="primary" onClick={handleClickStartTank}>
          START TANK
        </Button>
      </Grid>
      <Grid item xs={9}>
        <div>
          Dummy Text
        </div>
      </Grid>
    </Grid>
    <hr  width="90%"/>

   </div>
}

export default Home