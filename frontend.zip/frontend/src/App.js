import { Routes, Route } from 'react-router-dom'
import './App.css';
import Layout from './componets/Layout';
import Home from './componets/Home';
import QueryHF from './componets/QueryHF';
import BuyPet from './componets/BuyPet';
import BuyTank from './componets/BuyTank';
import StartTank from './componets/StartTank';
import TeamMembers from './componets/TeamMembers';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="/queryhf"  element={<QueryHF />} />
          <Route path="/buypet"  element={<BuyPet />} />
          <Route path="/buytank"  element={<BuyTank/>} />
          <Route path="/starttank"  element={<StartTank/>} />
          <Route path="/teammembers"  element={<TeamMembers/>} />
           </Route>
      </Routes>
    </div>
  );
}

export default App;
